
                <div id="footer" class="cf">
                    
                    <div class="column three"> 
                        <strong>Phone</strong><br>
                        2121.21212.121
                    </div>
                    
                    <div class="column three"> 
                        <strong>Location</strong><br>
                        ThePizzaVillage, PizzaTown<br>
                        Jupiter, Milky Way 
                    </div>
                    
                    <div class="column three last"> 
                        <strong>Hours</strong>
                        <em>Tuesday - Thursday</em><br>
                        1:00pm - 9:00pm<br><br>
                        
                        <em>Friday - Saturday</em><br>
                        4:00pm - 11:00pm<br><br>
                        
                        <em>Sunday - Monday</em><br>
                        Closed<br><br>
                    </div>
                    
                </div>
                
                <small>&copy; <?php echo date('Y'); ?> <?php echo $companyName  ; ?></small>
            </div>
        </div>
        
        <div class="copyright-info">
            <?php include('includes/copyright.php'); ?> 
            </div>
    </body>
</html>
