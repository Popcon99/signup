

<h4>PHP Login/Registration System - msaad1999</h4>
<h5>Copyright &copy;<?php echo date('Y');?> 
    <a href="https://www.linkedin.com/in/muhammadsaadhussaini/" target="_blank">
        msaad1999</a>, 
    Freelance Web Developer at  
    <a href="https://www.fiverr.com/msaad1999" target="_blank">
        Fiverr.com
    </a>
</h5>

